<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "styles/style.css">
    <title>Send Mail</title>
    <style>
        body{
            margin: 0 auto;
            width: 250px;
            align-items: center;
            padding: 25px;
        }
        input, textarea, select{
            box-sizing: border-box;
            display: block;
            width: 250px;
            height: 30px;
            font-family: 'Times New Roman', Times, serif;
            margin-bottom: 10px;
        }
        textarea{
            height: 75px;
            resize: none;
        }
    </style>
</head>
<body>
    <form action="sand_mail.php" method="post">
        <select name="subject">
            <option disabled selected>Тема письма</option>
            <option value="1">Так по делу</option>
            <option value="2">Личный вопрос</option>
            <option value="3">Благодарность</option>
        </select>
        <input type = "email" name = "email" placeholder="Введи адрес эл. почты" maxlength="50">
        <textarea name = "message" placeholder="Введите сообщение" maxlength="150" required></textarea>
        <input type = "submit" value="Отправить">
    </form>
</body>
</html>
<?php
    if($_POST["subject"] == 1){
        $subject = "Вопрос по уроку";
    }
    else if($_POST["subject"] == 2){
        $subject = "Личный вопрос";
    }
    else if($_POST["subject"] == 3){
        $subject = "Благодпарность";
    }
    else $subject = "Вопрос по уроку";

    $to = $_COOKIE["user_data"];
    $from = trim($_COOKIE["email"]); 
    echo $to . " " . $from; 

    $message = htmlspecialchars($_POST["message"]);
    $message = urlencode($message);
    $message = trim($message);

    $headers = "From: $from" . "\r\n" . 
     "Reply-To: $from" . "\r\n" . 
    "X-Mailer: PHP/" . phpversion();

    if(mail($to, $subject, $message, $headers)){
        echo "Письмо отправлено";
    } else {
        echo "Письмо не отправлено";
    }
?>
