<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie</title>
    <style>
        body{
            margin: 0 auto;
            width:800px;
        }
    </style>
</head>
<body>
    <br><h3> Задача 1 </h3>
    <form method = "post" >
        <input type=  'text' placeholder="Введите свой ник" name = "nicname"><br><p>Выбрать цвет</p>
        <input type= "color" value = "Выбрать цвет" name = "color">
        <input type= "submit" value = "Заполнить" name = "">
    </form>

    <br><h3> Задача 3</h3>

    <br><h3> Задача 4</h3>
    <form method = "post">
        <input type= 'text' placeholder="Введит свой логин" name = "Login"><br><p></p>
        <input type= "submit" value = "Вывести" name = "">
    </form>

    <br><h3> Задача 4</h3>
    <a href = "first_page.php">Перейти к 5й задаче</a>
    <a href = "form.php">Перейти к формам</a>
</body>
</html>
<?php 
    $nikname = $_POST["nicname"];
    /*setcookie("nikname", $nik, strtotime("+3000"));
    $_COOKIE["nikname"] = $nikname;
    echo ($_COOKIE["nikname"]);*/

    session_start();
    $_SESSION["nik"] = $nikname;
    echo ($_SESSION["nik"]);

    $btn_color = $_POST["color"];
    //if(isset($btn_color)){
        echo "<body style='background-color:".$btn_color . "'>";
    //}
    session_abort();

    //zadacha 3
    session_start();
    if (!in_array("http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'], $_SESSION['visited'])){
        print_r($_SESSION['visited'][] = "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
    }

    //zadacha 4
    $login = $_POST["Login"];
    setcookie("time", $user_login, strtotime("+3600000"));
    $_COOKIE["user_login"] = $login;
    if(isset( $_COOKIE["user_login"])){
        $now = date("H:i ; d:m:y");
        echo "Вы - { " . $_COOKIE["user_login"] . "} посещали сайт " . $now . " по Московскому времени!";
    }
?>