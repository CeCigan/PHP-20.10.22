<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie</title>
    <style>
        body{
            margin: 0 auto;
            width:800px;
        }
    </style>
</head>
<body>
    <a href = "1.php">Задача 1</a>
    <br><h3> Задача 4</h3>
    <form method = "post">
        <input type= 'text' placeholder="Введит свой логин" name = "Login"><br><p></p>
        <input type= "submit" value = "Вывести" name = "">
    </form>

    <br><h3> Задача 4</h3>
    <a href = "first_page.php">Перейти к 5й задаче</a><br>
    <a href = "form.htm">Перейти к формам</a>
</body>
</html>

<?php 
    //Задача 3
    echo "<h3>Задача 3</h3><br>";
    session_start();
    echo "<a href = './3_1.php'>3.1.php</a> <br>";
    echo "<a href = './3_2.php'>3.2.php</a> <br>";

    foreach($_COOKIE as $cookies){
        if($cookies[0] == ".") echo "<br>" . $cookies;
    }

    //zadacha 4
    $login = $_POST["Login"];
    setcookie("time", $user_login, strtotime("+3600"));
    $_COOKIE["user_login"] = $login;
    if(isset( $_COOKIE["user_login"])){
        $now = date("H:i ; d:m:y");
        echo "Вы - { " . $_COOKIE["user_login"] . "} посещали сайт " . $now . " по Московскому времени!";
    }
?>