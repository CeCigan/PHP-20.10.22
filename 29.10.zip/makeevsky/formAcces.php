<?php 
    if(isset($_POST["password"]) == isset($_POST["passwordAcces"])){
        echo "Подтвердите пароль";
    }

        $name = htmlentities($_POST["name"]);
        $password = htmlentities($_POST["password"]);
        $gender = htmlentities($_POST["gender"]);
        $text =htmlentities($_POST["text"]);
        $prof =htmlentities($_POST["prof"]);
        echo $output = "
        <html>
        <head>
        <title>Анкетные данные</title>
        </head>
        <body>
        Вас зовут: $name<br />
        Ваш пол: $gender<br />
        Ваша специальность: $prof <br / >
        Ваши навыки:
        <ul >";
        if(isset($_POST["Знание_HTML_и_CSS"])) echo "<li>Знание HTML и CSS" . "</li>";
        if(isset($_POST["Знание_Perl"])) echo "<li>Знание Perl" . "<br />";
        if(isset($_POST["Знание_ASP"])) echo "<li>Знание ASP" . "<br />";
        if(isset($_POST["Знание_Adobe_Photpshop"])) echo "<li>Знание Adobe Photpshop" . "</li>";
        if(isset($_POST["Знание_Java"])) echo "<li>Знание Java" . "</li>";
        if(isset($_POST["Знание_JavaScript"])) echo "<li>Знание JavaScript" . "</li>";
        if(isset($_POST["Знание_Flash"])) echo "<li>Знание Flash" . "</li>";

        echo "</ul>"
        echo "Расскажите  о себе: $text<br />"
?>