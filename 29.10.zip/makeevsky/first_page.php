<?php 
    $FIO = "Зубенко Михаил";
    $email = "vkid@com";
    $_SESSION["FIO"] = $FIO;
    $_SESSION["email"] = $email;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "styles/style.css">
    <title>Send Mail</title>
    <STYLE>
         body{
            margin: 0 auto;
            width: 250px;
            align-items: center;
            padding: 25px;
        }
        input, textarea, select{
            box-sizing: border-box;
            display: block;
            width: 250px;
            height: 30px;
            font-family: 'Times New Roman', Times, serif;
            margin-bottom: 10px;
        }
        textarea{
            height: 75px;
            resize: none;
        }
    </STYLE>
</head>
<body>
    <form action="first_page.php" method="post">
        <select name="subject">
            <option disabled selected>Тема письма</option>
            <option value="1">Так по делу</option>
            <option value="2">Личный вопрос</option>
            <option value="3">Благодарность</option>
        </select>
        <input type = "email" name = "email" placeholder="Введи адрес эл. почты" maxlength="50" value = "<?php echo $_SESSION["email"] = $email;?>">
        <input type = "text" name = "name" placeholder="Введит свое ФИО" maxlength="50" value = "<?php echo $_POST["name"] = $_SESSION["FIO"];?>">
        <textarea name = "message" placeholder="Введите сообщение" maxlength="150" required></textarea>
        <input type = "submit" value="Отправить">
    </form>
</body>
</html>
