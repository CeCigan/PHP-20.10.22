<?php 
    @setcookie("conter", $_COOKIE["counter"] + 1, strtotime("+ 30 days"));
    @setcookie("currentURL" . $_COOKIE["counter"], '..3_1.php', strtotime("+ 30 days"));
    echo "<a href = 'index.php'>back</a>";
?>