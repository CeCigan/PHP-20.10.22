<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie</title>
    <style>
        body{
            margin: 0 auto;
            width:800px;
        }
    </style>
</head>
<body>
    <br><h3> Задача 1</h3>
    <form method = "get" action = "1.php">
        <input type=  'text' placeholder="Введите свой ник" name = "nicname"><br><p>Выбрать цвет</p>
        <input type= "color" value = "Выбрать цвет" name = "color">
        <input type= "submit" value = "Заполнить" name = "">
    </form>
</body>
</html>    
    <?php 
    $nikname = $_GET["nicname"];
    /*setcookie("nikname", $nik, strtotime("+3000"));
    $_COOKIE["nikname"] = $nikname;
    echo ($_COOKIE["nikname"]);*/

    session_start();
    $_SESSION["nik"] = $nikname;
    echo ($_SESSION["nik"]);

    $color = $_POST["color"];
    //if(isset($btn_color)){
        echo "<body style='background-color:". $color . "';>";
    //}
    session_abort();
?>