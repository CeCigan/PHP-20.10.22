<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "styles/style.css">
    <title>Send Mail</title>
</head>
<body>
    <form action="sand_mail.php" method="post">
        <select name="subject">
            <option disabled selected>Тема письма</option>
            <option value="1">Вопросы к уроку</option>
            <option value="2">Личный вопрос</option>
            <option value="3">Благодарность</option>
        </select>
        <input type = "email" name = "email" 
            placeholder="Введи адрес эл. почты" maxlength="50" required>
        <textarea name = "message" placeholder="Введите сообщение" 
            maxlength="150" required></textarea>
        <img src = "./images/captcha.png">
        <input type = "text" name = "captcha" 
            placeholder="Введите текст из картинки" maxlength="20" required>
        <input type = "submit" value="Отправить">
    </form>
</body>
</html>